work (test) nginx config 

1. Wordpress

2. coin mine pool (Masari Monero Loki Ryo or Ombre Bittube)

https (LetsEncrypt)

 create new repo nginx-conf 
 git init
 git log
 git status
  git add /usr/local/etc/nginx/nginx.conf 

  1231	15:33	git remote add nginx-conf https://github.com/santosha2003/nginx-conf
  1232	15:33	git push
  1234	15:33	git push nginx-conf master
  1235	15:34	git push --set-upstream nginx-conf master
  1236	15:34	git remote
  1239	15:38	git push -u nginx-conf master
  1240	15:39	git remote add nginx-conf https://github.com/santosha2003/nginx-conf
  1241	15:40	git remote add nginx-conf https://github.com/santosha2003/nginx-conf.git
  1242	15:40	git push -u nginx-conf master
  1243	15:41	git fetch nginx-conf
  1244	15:41	git branch -r
  1245	15:41	git fetch nginx-conf
  1246	15:41	git push -u nginx-conf master
  1247	15:43	git commit
  1249	15:49	git push -u nginx-conf master
  1250	15:49	git fetch nginx-conf
  1251	15:49	git push -u nginx-conf master
  1252	15:49	git pull
  1255	15:50	h >> README.md
